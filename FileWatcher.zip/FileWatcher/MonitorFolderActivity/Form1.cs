using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO; //used for FileSystemWatcher and Directory
using System.Collections;
using System.Data.SqlClient;
using System.Configuration;  //used for ArrayList

namespace MonitorFolderActivity
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            DisableButtons();
            bool bMonitorUpdated = chkMonitorUpdated.Checked;
            bool bMonitorDeleted = chkMonitorDeleted.Checked; 
            bool bMonitorCreated = chkMonitorCreated.Checked;

            ArrayList aFileWatcherInstance = new ArrayList();

            foreach (string sMonitorFolder in lstFolders.Items)
            {
                //Check if Directory Exisits
                if (Directory.Exists(sMonitorFolder))
                {
                    FileSystemWatcher oFileWatcher = new FileSystemWatcher();

                    //Set the path that you want to monitor.
                    oFileWatcher.Path = sMonitorFolder;

                    //Set the Filter Expression.
                    oFileWatcher.Filter = txtMonitorFileExpression.Text;

                    if (bMonitorUpdated)
                        oFileWatcher.Changed += new System.IO.FileSystemEventHandler(FileSystemWatcherUpdated);
                    else
                        oFileWatcher.Changed -= new System.IO.FileSystemEventHandler(FileSystemWatcherUpdated);

                    if (bMonitorDeleted)
                        oFileWatcher.Deleted += new System.IO.FileSystemEventHandler(FileSystemWatcherDeleted);
                    else
                        oFileWatcher.Deleted -= new System.IO.FileSystemEventHandler(FileSystemWatcherDeleted);

                    if (bMonitorCreated)
                        oFileWatcher.Created += new System.IO.FileSystemEventHandler(FileSystemWatcherCreated);
                    else
                        oFileWatcher.Created -= new System.IO.FileSystemEventHandler(FileSystemWatcherCreated);

                    oFileWatcher.EnableRaisingEvents = true;

                    //Add a new instance of FileWatcher 
                    aFileWatcherInstance.Add(oFileWatcher);
                }
            }

        }
        void FileSystemWatcherCreated(object sender, System.IO.FileSystemEventArgs e)
        {
            //A file has been deleted from the monitor directory.
            string sLog = "File Created: " + e.Name;

            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[16] {
            new DataColumn("paymentmode"),
            new DataColumn("txnid"),
            new DataColumn("Ben_Name"),
            new DataColumn("Ben_code"),
            new DataColumn("Amount"),
            new DataColumn("Txn_date"),
            new DataColumn("Ben_accno") ,
            new DataColumn("Ben_ifsc"),
            new DataColumn("Payer_Accno"),
            new DataColumn("Utr_no"),
            new DataColumn("Filler1"),
            new DataColumn("Pay_status"),
            new DataColumn("Filler2"),
            new DataColumn("Ben_Name2"),
            new DataColumn("Ben_Name3"),
            new DataColumn("Ref_no")});

            StringBuilder sb = new StringBuilder();
            List<string> list = new List<string>();
            using (StreamReader sr = new StreamReader(e.FullPath))
            {
                while (sr.Peek() >= 0)
                {
                    list.Add(sr.ReadLine()); //Using readline method to read text file.
                }
            }
            //ignore the fist line (title line).
            for (int i = 1; i < list.Count; i++)
            {
                string[] strlist = list[i].Split('|'); //using string.split() method to split the string.
                dt.Rows.Add(strlist[0], strlist[1], strlist[2], strlist[3], strlist[4], strlist[5], strlist[6],
                    strlist[7], strlist[8], strlist[9], strlist[10], strlist[11], strlist[12], strlist[13], strlist[14], strlist[15]);

                //If you want to insert it into database, you could insert from here.
            }

            string ConnStr = ConfigurationManager.ConnectionStrings["dbConnection"].ConnectionString;

            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(ConnStr))
            {
                bulkCopy.DestinationTableName = "FILE_WATCHER";
                bulkCopy.ColumnMappings.Add("paymentmode", "paymentmode");
                bulkCopy.ColumnMappings.Add("txnid", "txnid");
                bulkCopy.ColumnMappings.Add("Ben_Name", "Ben_Name");
                bulkCopy.ColumnMappings.Add("Ben_code", "Ben_code");
                bulkCopy.ColumnMappings.Add("Amount", "Amount");
                bulkCopy.ColumnMappings.Add("Txn_date", "Txn_date");
                bulkCopy.ColumnMappings.Add("Ben_accno", "Ben_accno");
                bulkCopy.ColumnMappings.Add("Ben_ifsc", "Ben_ifsc");
                bulkCopy.ColumnMappings.Add("Payer_Accno", "Payer_Accno");
                bulkCopy.ColumnMappings.Add("Utr_no", "Utr_no");
                bulkCopy.ColumnMappings.Add("Filler1", "Filler1");
                bulkCopy.ColumnMappings.Add("Pay_status", "Pay_status");
                bulkCopy.ColumnMappings.Add("Filler2", "Filler2");
                bulkCopy.ColumnMappings.Add("Ben_Name2", "Ben_Name2");
                bulkCopy.ColumnMappings.Add("Ben_Name3", "Ben_Name3");
                bulkCopy.ColumnMappings.Add("Ref_no", "Ref_no");
                bulkCopy.WriteToServer(dt);
                //MessageBox.Show("UPLOAD SUCCESSFULLY");
            }
            AppendText(sLog);
        }
        void FileSystemWatcherDeleted(object sender, System.IO.FileSystemEventArgs e)
        {
            //A file has been deleted from the monitor directory.
            string sLog = "File Deleted: " + e.Name;
            AppendText(sLog);
        }
        void FileSystemWatcherUpdated(object sender, System.IO.FileSystemEventArgs e)
        {
            //A file has been deleted from the monitor directory.
            string sLog = "File Updated: " + e.Name;
            AppendText(sLog);
        }

        private delegate void AppendListHandler(string sLog);
        private void AppendText(string sLog)
        {
            if (lstResultLog.InvokeRequired)
                lstResultLog.Invoke(new AppendListHandler(AppendText), new object[] { sLog });
            else
                lstResultLog.Items.Add(Convert.ToString(DateTime.Now) + " - " + sLog);
        }

        private void DisableButtons()
        {
            chkMonitorUpdated.Enabled = false;
            chkMonitorDeleted.Enabled = false;
            chkMonitorCreated.Enabled = false;
            txtMonitorFileExpression.Enabled = false;
            btnRun.Enabled = false;

        }

        private void lstFolders_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}